export class Manager{
   

    public constructor( 
        public mId:number,
        public mUserName:string,
        public mPassword:string,
       public mEmail:string,
       public mContactNo:number){}
}
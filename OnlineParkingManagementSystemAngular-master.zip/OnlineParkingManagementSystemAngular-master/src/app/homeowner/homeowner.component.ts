import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeowner',
  templateUrl: './homeowner.component.html',
  styleUrls: ['./homeowner.component.css']
})
export class HomeownerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

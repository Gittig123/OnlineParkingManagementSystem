export class User
{
    public constructor
    (
    public id:number,
    public userName:string,
    public password:string,
    public firstname:string,
    public lastname:string,
    public email:string,
    public contactNo:number,
    public address:string){}
}

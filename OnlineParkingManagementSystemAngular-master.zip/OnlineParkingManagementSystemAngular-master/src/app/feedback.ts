export class Feedback
{
    public constructor(
        public Fbid:number,
        public Fbname:string,
        public Fbemail:string,
        public Fbmessage:string,
    ){}

}
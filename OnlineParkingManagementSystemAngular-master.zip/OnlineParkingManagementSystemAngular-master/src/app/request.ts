export class Request
{
    public constructor(
        public Rid:number,
        public Oid:number,
        public Rpsaddress:String,
        public Rpscount:number,
        public Rstatus:String,
        ){}
}
export class Booking
{
    public constructor(
       public Bid:number,
        public Bdate:string,
        public Tsslots:string,
        public Plname:string,
        public Aname:string,
        public Cname:string,
        public Bcharges:number,
        public Bmode:string,
        public Bpaymentstatus:string,
        public Status:string
    )
    {}
    
}

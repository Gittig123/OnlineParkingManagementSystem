export class Owner
{
   public constructor(
        public id:number,
        public ownerUsername:string,
        public password:string,
        public firstName:string,
        public lastName:string,
        public email:string,
        public contactno:number,
        public address:string,
        ){}
}




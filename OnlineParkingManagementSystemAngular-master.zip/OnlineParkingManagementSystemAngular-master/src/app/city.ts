export class City
{

    public constructor(
        public cid:number,
        public cname:string)
    {}
    
}
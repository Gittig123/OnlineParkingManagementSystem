export class Admin
{
    public constructor(
        public adminUserName:string,
        public adminPassword:string,
        public adminFirstName:string,
        public adminLastName:string
    )
    {}
    
}

# OnlineParkingManagementSystem

This project was generated with Maven

## Development server

Navigate to `http://localhost:8989/`

## Build

Update to build the project and Run

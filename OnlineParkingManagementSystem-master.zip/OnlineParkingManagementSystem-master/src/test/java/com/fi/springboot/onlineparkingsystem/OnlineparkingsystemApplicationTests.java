package com.fi.springboot.onlineparkingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineparkingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
